﻿namespace Recycle.Models
{
    public class ConnectionDto
    {
        public string ConnectionString { get; set; }

    }
}
