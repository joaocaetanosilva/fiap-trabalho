﻿namespace Recycle.Entyties
{
    public class Truck
    {
        public int Id { get; set; }
        public string Placa { get; set; }
    }
}
